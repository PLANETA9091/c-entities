# Базовый прогон: `tiles-100k`

Сервер: `1.21.8-60-29c8822 (MC: 1.21.8)`

## Итог

| метрика | значение |
|---|---|
| энтити заспавнено | 0 (items 0 / stands 0 / zombies 0) |
| тайл-энтити | 68121 (hoppers 42269 / furnaces 25852) |
| MSPT p50 / p90 / p99 / max, мс | 27.477 / 30.137 / 39.633 / 53.953 |
| MSPT mean, мс | 27.817 |
| TPS-оценка (1000/p50) | 20.0 |
| heap used / max, МБ | 683.2 / 8192.0 |
| замеров тиков | 600 |

## Что жрёт время (JFR, top-15 self-time)

| # | % | метод |
|---:|---:|---|
| 1 | 10.24% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.isRemoved() line: 956` |
| 2 | 9.75% | `net.minecraft.world.level.Level.tickBlockEntities() line: 1461` |
| 3 | 8.27% | `net.minecraft.world.item.ItemStack.getMaxStackSize() line: 581` |
| 4 | 5.39% | `java.util.HashMap.getNode(Object) line: 585` |
| 5 | 3.94% | `net.minecraft.server.level.ServerLevel.moonrise$getChunkTaskScheduler() line: 342` |
| 6 | 2.78% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 7 | 2.45% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.tick() line: 929` |
| 8 | 2.26% | `it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet.contains(Object) line: 446` |
| 9 | 1.81% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 10 | 1.74% | `net.minecraft.world.level.block.entity.BaseContainerBlockEntity.getItem(int) line: 127` |
| 11 | 1.61% | `net.minecraft.core.NonNullList.get(int) line: 44` |
| 12 | 1.55% | `net.minecraft.world.level.block.entity.HopperBlockEntity.pushItemsTick(Level, BlockPos, BlockState, HopperBlockEntity) line: 131` |
| 13 | 1.49% | `net.minecraft.world.level.chunk.LevelChunk.getBlockEntity(BlockPos, LevelChunk$EntityCreationType) line: 474` |
| 14 | 1.39% | `net.minecraft.core.Vec3i.equals(Object) line: 45` |
| 15 | 1.29% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.getBlock() line: 641` |

