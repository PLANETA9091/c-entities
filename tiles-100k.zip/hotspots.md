# JVM hotspots (JFR ExecutionSample)

Samples: 3097

## Top 60 by self-time (leaf frames)

| # | % | method |
|---:|---:|---|
| 1 | 10.24% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.isRemoved() line: 956` |
| 2 | 9.75% | `net.minecraft.world.level.Level.tickBlockEntities() line: 1461` |
| 3 | 8.27% | `net.minecraft.world.item.ItemStack.getMaxStackSize() line: 581` |
| 4 | 5.39% | `java.util.HashMap.getNode(Object) line: 585` |
| 5 | 3.94% | `net.minecraft.server.level.ServerLevel.moonrise$getChunkTaskScheduler() line: 342` |
| 6 | 2.78% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 7 | 2.45% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.tick() line: 929` |
| 8 | 2.26% | `it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet.contains(Object) line: 446` |
| 9 | 1.81% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 10 | 1.74% | `net.minecraft.world.level.block.entity.BaseContainerBlockEntity.getItem(int) line: 127` |
| 11 | 1.61% | `net.minecraft.core.NonNullList.get(int) line: 44` |
| 12 | 1.55% | `net.minecraft.world.level.block.entity.HopperBlockEntity.pushItemsTick(Level, BlockPos, BlockState, HopperBlockEntity) line: 131` |
| 13 | 1.49% | `net.minecraft.world.level.chunk.LevelChunk.getBlockEntity(BlockPos, LevelChunk$EntityCreationType) line: 474` |
| 14 | 1.39% | `net.minecraft.core.Vec3i.equals(Object) line: 45` |
| 15 | 1.29% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.getBlock() line: 641` |
| 16 | 1.23% | `net.minecraft.world.level.block.entity.BlockEntity.getBlockPos() line: 244` |
| 17 | 1.19% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.CRC.updateCRC(int) line: 119` |
| 18 | 1.19% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 201` |
| 19 | 1.07% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 275` |
| 20 | 0.84% | `java.util.Arrays$ArrayList.get(int) line: 4266` |
| 21 | 0.77% | `com.google.common.collect.RegularImmutableList.get(int) line: 79` |
| 22 | 0.74% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 23 | 0.71% | `net.minecraft.world.level.block.entity.BlockEntity.isRemoved() line: 261` |
| 24 | 0.52% | `ca.spottedleaf.moonrise.patches.starlight.light.StarLightEngine.performLightIncrease(LightChunkGetter) line: 1144` |
| 25 | 0.45% | `net.minecraft.core.Vec3i.getY() line: 67` |
| 26 | 0.45% | `net.minecraft.world.level.ChunkPos.asLong(int, int) line: 85` |
| 27 | 0.42% | `net.minecraft.server.level.ServerLevel.tickChunk(LevelChunk, int) line: 916` |
| 28 | 0.42% | `net.minecraft.world.level.chunk.PalettedContainer.swapPalette(int[], IntUnaryOperator) line: 376` |
| 29 | 0.39% | `net.minecraft.nbt.CompoundTag.writeNamedTag(String, Tag, DataOutput) line: 433` |
| 30 | 0.36% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 714` |
| 31 | 0.36% | `ca.spottedleaf.moonrise.patches.chunk_system.scheduling.ChunkHolderManager.getChunkHolder(long) line: 930` |
| 32 | 0.32% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 742` |
| 33 | 0.32% | `net.minecraft.world.item.ItemStack.isEmpty() line: 313` |
| 34 | 0.32% | `ca.spottedleaf.moonrise.patches.blockstate_propertyaccess.util.ZeroCollidingReferenceStateTable.get(long, Property) line: 117` |
| 35 | 0.32% | `net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity.serverTick(ServerLevel, BlockPos, BlockState, AbstractFurnaceBlockEntity) line: 188` |
| 36 | 0.32% | `net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity.isLit() line: 152` |
| 37 | 0.29% | `net.minecraft.world.level.chunk.LevelChunkSection.updateBlockCallback(int, int, int, BlockState, BlockState) line: 129` |
| 38 | 0.29% | `net.minecraft.world.level.chunk.LinearPalette.idFor(Object) line: 52` |
| 39 | 0.29% | `com.google.common.collect.Iterators.forArrayWithPosition(Object[], int) line: 1075` |
| 40 | 0.29% | `com.google.common.collect.Iterators$ArrayItr.<init>(Object[], int) line: 1086` |
| 41 | 0.29% | `net.minecraft.world.level.chunk.PalettedContainer.swapPalette(int[], IntUnaryOperator) line: 374` |
| 42 | 0.26% | `com.sun.crypto.provider.GHASH.processBlocks(byte[], int, int, long[], long[]) line: 285` |
| 43 | 0.26% | `com.sun.crypto.provider.GHASH.processBlocks(byte[], int, int, long[], long[]) line: 282` |
| 44 | 0.26% | `net.minecraft.world.level.chunk.ProtoChunk.setBlockState(BlockPos, BlockState, int) line: 177` |
| 45 | 0.26% | `net.minecraft.world.level.levelgen.material.MaterialRuleList.calculate(DensityFunction$FunctionContext) line: 12` |
| 46 | 0.26% | `net.minecraft.world.level.chunk.ImposterProtoChunk.getNoiseBiome(int, int, int) line: 175` |
| 47 | 0.26% | `ca.spottedleaf.moonrise.patches.starlight.light.SWMRNibbleArray.getUpdating(int) line: 388` |
| 48 | 0.26% | `net.minecraft.server.level.ServerLevel.areEntitiesLoaded(long) line: 2516` |
| 49 | 0.23% | `java.lang.String.hashCode() line: 2358` |
| 50 | 0.23% | `net.minecraft.world.level.chunk.PalettedContainer$Data.copyFrom(Palette, BitStorage) line: 468` |
| 51 | 0.23% | `net.minecraft.world.level.levelgen.NoiseChunk$NoiseInterpolator.updateForZ(double) line: 737` |
| 52 | 0.23% | `net.minecraft.world.level.levelgen.SurfaceRules$SequenceRule.tryApply(int, int, int) line: 590` |
| 53 | 0.23% | `net.minecraft.world.level.levelgen.synth.ImprovedNoise.p(int) line: 82` |
| 54 | 0.23% | `net.minecraft.util.SimpleBitStorage.get(int) line: 336` |
| 55 | 0.23% | `net.minecraft.world.level.redstone.NeighborUpdater.executeUpdate(Level, BlockState, BlockPos, Block, Orientation, boolean, BlockPos) line: 63` |
| 56 | 0.23% | `net.minecraft.util.SimpleBitStorage.get(int) line: 334` |
| 57 | 0.23% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getHash(long) line: 154` |
| 58 | 0.23% | `net.minecraft.util.SimpleBitStorage.get(int) line: 333` |
| 59 | 0.23% | `net.minecraft.world.RandomizableContainer.unpackLootTable(Player, boolean) line: 84` |
| 60 | 0.23% | `net.minecraft.nbt.CompoundTag.copy() line: 410` |

## Top 30 callers of hot leaves

| # | % | method |
|---:|---:|---|
| 1 | 10.24% | `net.minecraft.world.level.chunk.LevelChunk$RebindableTickingBlockEntityWrapper.isRemoved() line: 1004` |
| 2 | 9.85% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 819` |
| 3 | 5.46% | `java.util.LinkedHashMap.get(Object) line: 536` |
| 4 | 4.23% | `net.minecraft.server.level.ServerLevel.shouldTickBlocksAt(long) line: 830` |
| 5 | 3.42% | `net.minecraft.world.level.block.entity.HopperBlockEntity.getFullState(HopperBlockEntity) line: 173` |
| 6 | 3.04% | `net.minecraft.world.Container.getMaxStackSize(ItemStack) line: 32` |
| 7 | 2.65% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 279` |
| 8 | 2.52% | `net.minecraft.world.level.chunk.LevelChunk$RebindableTickingBlockEntityWrapper.tick() line: 999` |
| 9 | 2.26% | `java.util.ArrayList.batchRemove(Collection, boolean, int, int) line: 905` |
| 10 | 2.23% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.get(long) line: 224` |
| 11 | 1.81% | `net.minecraft.world.level.block.entity.HopperBlockEntity.isFullContainer(Container, Direction) line: 522` |
| 12 | 1.74% | `net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity.getItem(int) line: 58` |
| 13 | 1.74% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 14 | 1.68% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.tick() line: 929` |
| 15 | 1.45% | `net.minecraft.world.level.Level.getBlockEntity(BlockPos) line: 1640` |
| 16 | 1.39% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 328` |
| 17 | 1.36% | `net.minecraft.world.level.Level.getBlockState(BlockPos) line: 1340` |
| 18 | 1.19% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.setupNoRandPartC() line: 948` |
| 19 | 1.19% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.getPos() line: 961` |
| 20 | 1.16% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.initBlock() line: 326` |
| 21 | 0.94% | `net.minecraft.world.level.block.entity.BaseContainerBlockEntity.getItem(int) line: 127` |
| 22 | 0.87% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.is(Block) line: 990` |
| 23 | 0.84% | `net.minecraft.core.NonNullList.get(int) line: 44` |
| 24 | 0.77% | `net.minecraft.world.level.chunk.status.ChunkDependencies.get(int) line: 51` |
| 25 | 0.77% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 26 | 0.74% | `ca.spottedleaf.moonrise.patches.starlight.light.StarLightEngine.performLightDecrease(LightChunkGetter) line: 1436` |
| 27 | 0.74% | `net.minecraft.world.level.chunk.PalettedContainer.pack(IdMap, PalettedContainer$Strategy) line: 352` |
| 28 | 0.71% | `net.minecraft.world.level.chunk.LevelChunk$BoundTickingBlockEntity.isRemoved() line: 956` |
| 29 | 0.68% | `net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity.serverTick(ServerLevel, BlockPos, BlockState, AbstractFurnaceBlockEntity) line: 188` |
| 30 | 0.55% | `net.minecraft.world.level.block.AbstractFurnaceBlock.lambda$createFurnaceTicker$0(ServerLevel, Level, BlockPos, BlockState, AbstractFurnaceBlockEntity) line: 90` |

GC pauses: 0, total 0 ms

