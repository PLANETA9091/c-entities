# Базовый прогон: `mobs-25k`

Сервер: `1.21.8-60-29c8822 (MC: 1.21.8)`

## Итог

| метрика | значение |
|---|---|
| энтити заспавнено | 25000 (items 0 / stands 0 / zombies 25000) (merge-усадка: 25058 → 25058) |
| тайл-энтити | 0 (hoppers 0 / furnaces 0) |
| MSPT p50 / p90 / p99 / max, мс | 488.894 / 522.370 / 568.492 / 589.187 |
| MSPT mean, мс | 491.955 |
| TPS-оценка (1000/p50) | 2.0 |
| heap used / max, МБ | 1334.4 / 8192.0 |
| замеров тиков | 600 |

## Что жрёт время (JFR, top-15 self-time)

| # | % | метод |
|---:|---:|---|
| 1 | 25.40% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 2 | 5.61% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 543` |
| 3 | 3.65% | `java.util.HashMap.getNode(Object) line: 585` |
| 4 | 2.88% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 5 | 2.43% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 542` |
| 6 | 2.03% | `net.minecraft.world.entity.Entity.setTicksFrozen(int) line: 3636` |
| 7 | 1.15% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet$SetIterator.next() line: 987` |
| 8 | 1.07% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet.iterator() line: 1115` |
| 9 | 1.03% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 10 | 1.01% | `net.minecraft.core.component.PatchedDataComponentMap.get(DataComponentType) line: 61` |
| 11 | 0.96% | `net.minecraft.world.entity.Entity.setSharedFlag(int, boolean) line: 3599` |
| 12 | 0.94% | `net.minecraft.world.entity.Entity.getBoundingBox() line: 4387` |
| 13 | 0.87% | `net.minecraft.world.entity.LivingEntity.canCollideWithBukkit(Entity) line: 3849` |
| 14 | 0.86% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 70` |
| 15 | 0.76% | `net.minecraft.world.phys.Vec3.<init>(double, double, double) line: 70` |

