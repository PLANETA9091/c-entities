# JVM hotspots (JFR ExecutionSample)

Samples: 42332

## Top 60 by self-time (leaf frames)

| # | % | method |
|---:|---:|---|
| 1 | 25.40% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 2 | 5.61% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 543` |
| 3 | 3.65% | `java.util.HashMap.getNode(Object) line: 585` |
| 4 | 2.88% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 5 | 2.43% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 542` |
| 6 | 2.03% | `net.minecraft.world.entity.Entity.setTicksFrozen(int) line: 3636` |
| 7 | 1.15% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet$SetIterator.next() line: 987` |
| 8 | 1.07% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet.iterator() line: 1115` |
| 9 | 1.03% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 10 | 1.01% | `net.minecraft.core.component.PatchedDataComponentMap.get(DataComponentType) line: 61` |
| 11 | 0.96% | `net.minecraft.world.entity.Entity.setSharedFlag(int, boolean) line: 3599` |
| 12 | 0.94% | `net.minecraft.world.entity.Entity.getBoundingBox() line: 4387` |
| 13 | 0.87% | `net.minecraft.world.entity.LivingEntity.canCollideWithBukkit(Entity) line: 3849` |
| 14 | 0.86% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 70` |
| 15 | 0.76% | `net.minecraft.world.phys.Vec3.<init>(double, double, double) line: 70` |
| 16 | 0.74% | `net.minecraft.world.entity.LivingEntity.getHealth() line: 1376` |
| 17 | 0.73% | `java.util.EnumMap.get(Object) line: 247` |
| 18 | 0.72% | `java.lang.ThreadLocal$ThreadLocalMap.getEntry(ThreadLocal) line: 504` |
| 19 | 0.70% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 545` |
| 20 | 0.70% | `net.minecraft.world.entity.LivingEntity.getSleepingPos() line: 4378` |
| 21 | 0.66% | `net.minecraft.world.entity.ai.goal.GoalSelector.tickRunningGoals(boolean) line: 124` |
| 22 | 0.63% | `net.minecraft.world.entity.LivingEntity.tickEffects() line: 940` |
| 23 | 0.62% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 24 | 0.61% | `net.minecraft.world.entity.ai.goal.GoalSelector.tick() line: 88` |
| 25 | 0.60% | `net.minecraft.world.entity.Entity.setDeltaMovement(Vec3) line: 4883` |
| 26 | 0.59% | `net.minecraft.world.entity.ai.attributes.AttributeMap.getValue(Holder) line: 60` |
| 27 | 0.58% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 28 | 0.58% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 201` |
| 29 | 0.56% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 323` |
| 30 | 0.53% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices.getEntities(Class, Entity, AABB, List, Predicate) line: 381` |
| 31 | 0.49% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.getBlock() line: 641` |
| 32 | 0.48% | `net.minecraft.util.Mth.floor(double) line: 67` |
| 33 | 0.47% | `net.minecraft.world.entity.Entity.applyEffectsFromBlocks() line: 1269` |
| 34 | 0.46% | `net.minecraft.world.entity.LivingEntity.aiStep() line: 3456` |
| 35 | 0.46% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 275` |
| 36 | 0.46% | `net.minecraft.world.entity.LivingEntity.refreshDirtyAttributes() line: 1313` |
| 37 | 0.45% | `net.minecraft.util.SimpleBitStorage.get(int) line: 336` |
| 38 | 0.43% | `java.util.EnumMap.isValidKey(Object) line: 319` |
| 39 | 0.41% | `net.minecraft.core.Vec3i.getZ() line: 71` |
| 40 | 0.41% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 320` |
| 41 | 0.41% | `java.util.stream.AbstractPipeline.copyInto(Sink, Spliterator) line: 509` |
| 42 | 0.40% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 324` |
| 43 | 0.38% | `java.util.Arrays.copyOf(Object[], int) line: 3482` |
| 44 | 0.37% | `net.minecraft.world.entity.Entity.getOnPos(float) line: 1422` |
| 45 | 0.35% | `java.util.Collections.unmodifiableSet(Set) line: 1238` |
| 46 | 0.35% | `net.minecraft.network.syncher.SynchedEntityData.getItem(EntityDataAccessor) line: 49` |
| 47 | 0.35% | `java.util.ArrayDeque.size() line: 648` |
| 48 | 0.34% | `it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap.get(Object) line: 323` |
| 49 | 0.34% | `net.minecraft.world.entity.ai.sensing.Sensing.tick() line: 20` |
| 50 | 0.32% | `java.util.EnumMap.unmaskNull(Object) line: 127` |
| 51 | 0.31% | `net.minecraft.world.entity.ai.sensing.Sensing.tick() line: 21` |
| 52 | 0.30% | `net.minecraft.world.level.chunk.PalettedContainer.readPalette(PalettedContainer$Data, int) line: 96` |
| 53 | 0.29% | `net.minecraft.world.entity.Entity.moonrise$getChunkData() line: 411` |
| 54 | 0.29% | `net.minecraft.util.Mth.floor(double) line: 66` |
| 55 | 0.28% | `net.minecraft.world.item.enchantment.Enchantment.entityContext(ServerLevel, int, Entity, Vec3) line: 437` |
| 56 | 0.28% | `net.minecraft.server.level.ServerEntity.sendDirtyEntityData() line: 419` |
| 57 | 0.27% | `net.minecraft.world.phys.Vec3.distanceToSqr(Vec3) line: 134` |
| 58 | 0.26% | `net.minecraft.network.syncher.SynchedEntityData$DataItem.getValue() line: 214` |
| 59 | 0.26% | `java.lang.ThreadLocal.get() line: 172` |
| 60 | 0.26% | `net.minecraft.world.level.pathfinder.Path.getNextNodePos() line: 89` |

## Top 30 callers of hot leaves

| # | % | method |
|---:|---:|---|
| 1 | 25.40% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 2 | 9.04% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices.getEntities(Entity, AABB, List, Predicate) line: 327` |
| 3 | 3.81% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 545` |
| 4 | 3.66% | `java.util.HashMap.containsKey(Object) line: 602` |
| 5 | 2.03% | `net.minecraft.world.entity.LivingEntity.aiStep() line: 3553` |
| 6 | 1.34% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.get(long) line: 224` |
| 7 | 1.13% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.applyAndClear(Entity) line: 54` |
| 8 | 1.07% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet.iterator() line: 78` |
| 9 | 1.03% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 10 | 1.00% | `net.minecraft.core.component.DataComponentHolder.get(DataComponentType) line: 12` |
| 11 | 0.96% | `net.minecraft.world.entity.Entity.setSwimming(boolean) line: 3528` |
| 12 | 0.88% | `java.lang.ThreadLocal.get(Thread) line: 187` |
| 13 | 0.87% | `net.minecraft.world.entity.EntitySelector.lambda$pushable$9(boolean, Entity, Team, Team$CollisionRule, Entity) line: 58` |
| 14 | 0.77% | `net.minecraft.world.phys.Vec3.add(double, double, double) line: 119` |
| 15 | 0.76% | `net.minecraft.world.entity.LivingEntity.isAlive() line: 2152` |
| 16 | 0.74% | `net.minecraft.world.entity.ai.attributes.AttributeMap.getValue(Holder) line: 60` |
| 17 | 0.73% | `net.minecraft.world.entity.Entity.push(double, double, double, Entity) line: 2274` |
| 18 | 0.70% | `net.minecraft.world.entity.ai.goal.GoalSelector.tickRunningGoals(boolean) line: 124` |
| 19 | 0.70% | `net.minecraft.world.entity.LivingEntity.isSleeping() line: 4390` |
| 20 | 0.68% | `net.minecraft.world.entity.LivingEntity.getAttributeValue(Holder) line: 2721` |
| 21 | 0.68% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 279` |
| 22 | 0.65% | `net.minecraft.server.level.ChunkMap.newTrackerTick() line: 1016` |
| 23 | 0.65% | `net.minecraft.world.entity.Mob.serverAiStep() line: 759` |
| 24 | 0.64% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 25 | 0.63% | `net.minecraft.world.entity.LivingEntity.baseTick() line: 513` |
| 26 | 0.62% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 793` |
| 27 | 0.61% | `net.minecraft.network.syncher.SynchedEntityData.get(EntityDataAccessor) line: 53` |
| 28 | 0.57% | `net.minecraft.world.entity.LivingEntity.collectEquipmentChanges() line: 3348` |
| 29 | 0.55% | `net.minecraft.world.entity.Entity.collide(Vec3) line: 1516` |
| 30 | 0.53% | `it.unimi.dsi.fastutil.objects.ReferenceCollections$UnmodifiableCollection.contains(Object) line: 344` |

GC pauses: 0, total 0 ms

