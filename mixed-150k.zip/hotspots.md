# JVM hotspots (JFR ExecutionSample)

Samples: 77269

## Top 60 by self-time (leaf frames)

| # | % | method |
|---:|---:|---|
| 1 | 42.68% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 2 | 7.61% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 543` |
| 3 | 2.72% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 4 | 1.87% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 542` |
| 5 | 1.46% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 6 | 0.89% | `net.minecraft.network.syncher.SynchedEntityData.getItem(EntityDataAccessor) line: 49` |
| 7 | 0.89% | `java.util.HashMap.getNode(Object) line: 585` |
| 8 | 0.88% | `net.minecraft.world.entity.Entity.getBoundingBox() line: 4387` |
| 9 | 0.88% | `net.minecraft.world.entity.LivingEntity.getHealth() line: 1376` |
| 10 | 0.81% | `net.minecraft.server.level.ServerEntity.sendChanges() line: 151` |
| 11 | 0.78% | `net.minecraft.world.entity.Entity.setTicksFrozen(int) line: 3636` |
| 12 | 0.71% | `net.minecraft.world.entity.Entity.applyEffectsFromBlocks() line: 1269` |
| 13 | 0.66% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 14 | 0.65% | `net.minecraft.world.entity.Entity.setOldPos(Vec3) line: 2182` |
| 15 | 0.62% | `net.minecraft.world.entity.Entity.getSharedFlag(int) line: 3591` |
| 16 | 0.59% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 201` |
| 17 | 0.57% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 70` |
| 18 | 0.57% | `net.minecraft.world.entity.LivingEntity.tickEffects() line: 940` |
| 19 | 0.56% | `net.minecraft.util.SimpleBitStorage.get(int) line: 336` |
| 20 | 0.49% | `net.minecraft.world.entity.LivingEntity.getSleepingPos() line: 4378` |
| 21 | 0.46% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices.getEntities(Class, Entity, AABB, List, Predicate) line: 381` |
| 22 | 0.46% | `java.lang.ThreadLocal$ThreadLocalMap.getEntry(ThreadLocal) line: 504` |
| 23 | 0.45% | `java.lang.ThreadLocal.get() line: 172` |
| 24 | 0.44% | `net.minecraft.network.syncher.SynchedEntityData$DataItem.getValue() line: 214` |
| 25 | 0.44% | `net.minecraft.core.component.PatchedDataComponentMap.get(DataComponentType) line: 61` |
| 26 | 0.44% | `net.minecraft.world.entity.Entity.setDeltaMovement(Vec3) line: 4883` |
| 27 | 0.43% | `net.minecraft.util.Mth.floor(double) line: 67` |
| 28 | 0.42% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 323` |
| 29 | 0.42% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 30 | 0.42% | `net.minecraft.world.entity.ai.attributes.AttributeInstance.getModifier(ResourceLocation) line: 68` |
| 31 | 0.41% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet$SetIterator.next() line: 987` |
| 32 | 0.41% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 545` |
| 33 | 0.40% | `net.minecraft.world.entity.ai.attributes.AttributeMap.getInstance(Holder) line: 47` |
| 34 | 0.37% | `net.minecraft.world.entity.Entity.isNoGravity() line: 1830` |
| 35 | 0.36% | `it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap.put(Object, double) line: 485` |
| 36 | 0.35% | `java.util.EnumMap.isValidKey(Object) line: 319` |
| 37 | 0.33% | `it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap.get(Object) line: 323` |
| 38 | 0.33% | `net.minecraft.util.Mth.floor(double) line: 66` |
| 39 | 0.31% | `net.minecraft.server.level.ServerEntity.sendDirtyEntityData() line: 419` |
| 40 | 0.31% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.getBlock() line: 641` |
| 41 | 0.30% | `net.minecraft.server.level.ChunkMap$TrackedEntity.moonrise$clearPlayers() line: 1215` |
| 42 | 0.30% | `java.util.Arrays.copyOf(Object[], int) line: 3482` |
| 43 | 0.30% | `net.minecraft.world.entity.Entity.moonrise$getChunkData() line: 411` |
| 44 | 0.26% | `net.minecraft.world.level.NaturalSpawner.createState(int, Iterable, NaturalSpawner$ChunkGetter, LocalMobCapCalculator, boolean) line: 80` |
| 45 | 0.26% | `net.minecraft.world.entity.ai.goal.GoalSelector.tickRunningGoals(boolean) line: 124` |
| 46 | 0.26% | `it.unimi.dsi.fastutil.objects.ObjectArrayList.clear() line: 431` |
| 47 | 0.25% | `net.minecraft.world.level.chunk.PalettedContainer.readPalette(PalettedContainer$Data, int) line: 96` |
| 48 | 0.24% | `net.minecraft.world.entity.item.ItemEntity.getItem() line: 518` |
| 49 | 0.23% | `it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet.iterator() line: 1115` |
| 50 | 0.22% | `java.util.EnumMap.unmaskNull(Object) line: 127` |
| 51 | 0.22% | `net.minecraft.world.phys.Vec3.distanceToSqr(Vec3) line: 135` |
| 52 | 0.22% | `net.minecraft.world.entity.Entity.updateFluidHeightAndDoFluidPushing(TagKey, double) line: 4732` |
| 53 | 0.21% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 792` |
| 54 | 0.20% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 275` |
| 55 | 0.20% | `java.util.ArrayDeque.size() line: 648` |
| 56 | 0.20% | `net.minecraft.world.entity.LivingEntity.collectEquipmentChanges() line: 3348` |
| 57 | 0.19% | `net.minecraft.world.entity.Entity.setSharedFlag(int, boolean) line: 3599` |
| 58 | 0.19% | `java.util.EnumMap.get(Object) line: 247` |
| 59 | 0.18% | `net.minecraft.world.entity.ai.goal.GoalSelector.tick() line: 88` |
| 60 | 0.18% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap.get(Object) line: 324` |

## Top 30 callers of hot leaves

| # | % | method |
|---:|---:|---|
| 1 | 42.68% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 2 | 9.94% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices.getEntities(Entity, AABB, List, Predicate) line: 327` |
| 3 | 3.60% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 545` |
| 4 | 1.46% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 793` |
| 5 | 1.33% | `net.minecraft.network.syncher.SynchedEntityData.get(EntityDataAccessor) line: 53` |
| 6 | 1.24% | `net.minecraft.server.level.ChunkMap.newTrackerTick() line: 1016` |
| 7 | 1.14% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.get(long) line: 224` |
| 8 | 0.98% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 9 | 0.90% | `java.util.HashMap.containsKey(Object) line: 602` |
| 10 | 0.88% | `net.minecraft.world.entity.LivingEntity.isAlive() line: 2152` |
| 11 | 0.79% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.applyAndClear(Entity) line: 54` |
| 12 | 0.78% | `net.minecraft.world.entity.LivingEntity.aiStep() line: 3553` |
| 13 | 0.69% | `net.minecraft.world.entity.Entity.setOldPos() line: 2174` |
| 14 | 0.61% | `net.minecraft.world.entity.Entity.updateInWaterStateAndDoWaterCurrentPushing() line: 1970` |
| 15 | 0.57% | `net.minecraft.world.entity.LivingEntity.baseTick() line: 513` |
| 16 | 0.57% | `net.minecraft.world.entity.LivingEntity.aiStep() line: 3542` |
| 17 | 0.57% | `net.minecraft.world.entity.Entity.isSprinting() line: 3501` |
| 18 | 0.56% | `java.lang.ThreadLocal.get(Thread) line: 187` |
| 19 | 0.50% | `net.minecraft.world.entity.LivingEntity.isSleeping() line: 4390` |
| 20 | 0.48% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.EntityLookup.getEntities(Class, Entity, AABB, List, Predicate) line: 718` |
| 21 | 0.48% | `net.minecraft.util.profiling.Profiler.get() line: 47` |
| 22 | 0.45% | `net.minecraft.world.entity.Entity.updateFluidHeightAndDoFluidPushing(TagKey, double) line: 4788` |
| 23 | 0.45% | `net.minecraft.core.component.DataComponentHolder.get(DataComponentType) line: 12` |
| 24 | 0.43% | `java.util.Map.computeIfAbsent(Object, Function) line: 1064` |
| 25 | 0.42% | `net.minecraft.server.level.ServerChunkCache.tickChunks(ProfilerFiller, long) line: 561` |
| 26 | 0.42% | `net.minecraft.world.entity.LivingEntity.removeFrost() line: 533` |
| 27 | 0.40% | `net.minecraft.world.entity.LivingEntity.getAttribute(Holder) line: 2717` |
| 28 | 0.39% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 279` |
| 29 | 0.39% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices.getEntities(Class, Entity, AABB, List, Predicate) line: 381` |
| 30 | 0.37% | `net.minecraft.world.entity.Entity.getGravity() line: 1842` |

GC pauses: 0, total 0 ms

