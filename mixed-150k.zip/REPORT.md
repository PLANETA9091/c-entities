# Базовый прогон: `mixed-150k`

Сервер: `1.21.8-60-29c8822 (MC: 1.21.8)`

## Итог

| метрика | значение |
|---|---|
| энтити заспавнено | 150000 (items 105073 / stands 30072 / zombies 14855) (merge-усадка: 110242 → 110242) |
| тайл-энтити | 0 (hoppers 0 / furnaces 0) |
| MSPT p50 / p90 / p99 / max, мс | 909.686 / 1014.156 / 1082.055 / 1185.789 |
| MSPT mean, мс | 913.680 |
| TPS-оценка (1000/p50) | 1.1 |
| heap used / max, МБ | 1642.0 / 8192.0 |
| замеров тиков | 600 |

## Что жрёт время (JFR, top-15 self-time)

| # | % | метод |
|---:|---:|---|
| 1 | 42.68% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 2 | 7.61% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 543` |
| 3 | 2.72% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 4 | 1.87% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.ChunkEntitySlices$EntityCollectionBySection.getEntities(Entity, AABB, List, Predicate) line: 542` |
| 5 | 1.46% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 6 | 0.89% | `net.minecraft.network.syncher.SynchedEntityData.getItem(EntityDataAccessor) line: 49` |
| 7 | 0.89% | `java.util.HashMap.getNode(Object) line: 585` |
| 8 | 0.88% | `net.minecraft.world.entity.Entity.getBoundingBox() line: 4387` |
| 9 | 0.88% | `net.minecraft.world.entity.LivingEntity.getHealth() line: 1376` |
| 10 | 0.81% | `net.minecraft.server.level.ServerEntity.sendChanges() line: 151` |
| 11 | 0.78% | `net.minecraft.world.entity.Entity.setTicksFrozen(int) line: 3636` |
| 12 | 0.71% | `net.minecraft.world.entity.Entity.applyEffectsFromBlocks() line: 1269` |
| 13 | 0.66% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 14 | 0.65% | `net.minecraft.world.entity.Entity.setOldPos(Vec3) line: 2182` |
| 15 | 0.62% | `net.minecraft.world.entity.Entity.getSharedFlag(int) line: 3591` |

