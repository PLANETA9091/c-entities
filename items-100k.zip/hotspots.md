# JVM hotspots (JFR ExecutionSample)

Samples: 8037

## Top 60 by self-time (leaf frames)

| # | % | method |
|---:|---:|---|
| 1 | 7.89% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 2 | 5.84% | `net.minecraft.world.entity.Entity.setOldPos(Vec3) line: 2182` |
| 3 | 5.08% | `net.minecraft.server.level.ServerEntity.sendChanges() line: 151` |
| 4 | 3.36% | `net.minecraft.world.entity.Entity.setSharedFlag(int, boolean) line: 3599` |
| 5 | 3.12% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 70` |
| 6 | 2.87% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 7 | 2.15% | `net.minecraft.world.entity.Entity.applyEffectsFromBlocks() line: 1269` |
| 8 | 2.10% | `net.minecraft.world.entity.Entity.isNoGravity() line: 1830` |
| 9 | 1.98% | `net.minecraft.network.syncher.SynchedEntityData.getItem(EntityDataAccessor) line: 49` |
| 10 | 1.78% | `net.minecraft.world.entity.Entity.moonrise$getChunkData() line: 411` |
| 11 | 1.63% | `net.minecraft.world.phys.Vec3.<init>(double, double, double) line: 69` |
| 12 | 1.57% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 13 | 1.48% | `net.minecraft.server.level.ChunkMap$TrackedEntity.moonrise$clearPlayers() line: 1215` |
| 14 | 1.24% | `net.minecraft.world.entity.item.ItemEntity.getItem() line: 518` |
| 15 | 1.23% | `it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap.put(Object, double) line: 485` |
| 16 | 1.22% | `net.minecraft.util.SimpleBitStorage.get(int) line: 336` |
| 17 | 1.19% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 201` |
| 18 | 0.98% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 19 | 0.98% | `net.minecraft.util.Mth.floor(double) line: 67` |
| 20 | 0.97% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 792` |
| 21 | 0.88% | `net.minecraft.server.level.ServerLevel.lambda$tick$4(TickRateManager, ProfilerFiller, Entity) line: 795` |
| 22 | 0.88% | `ca.spottedleaf.moonrise.patches.chunk_system.level.entity.EntityLookup$ArrayIterable$ArrayIterator.next() line: 160` |
| 23 | 0.87% | `java.util.Arrays.copyOf(Object[], int) line: 3482` |
| 24 | 0.82% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 77` |
| 25 | 0.77% | `net.minecraft.network.syncher.SynchedEntityData$DataItem.getValue() line: 214` |
| 26 | 0.76% | `it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet.contains(Object) line: 450` |
| 27 | 0.71% | `net.minecraft.world.phys.Vec3.distanceToSqr(Vec3) line: 134` |
| 28 | 0.65% | `net.minecraft.world.phys.Vec3.lengthSqr() line: 183` |
| 29 | 0.65% | `it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap.getDouble(Object) line: 431` |
| 30 | 0.65% | `net.minecraft.world.entity.Entity.updateFluidHeightAndDoFluidPushing(TagKey, double) line: 4732` |
| 31 | 0.62% | `net.minecraft.world.level.Level.isOutsideBuildHeight(int) line: 781` |
| 32 | 0.61% | `net.minecraft.util.Mth.floor(double) line: 66` |
| 33 | 0.58% | `net.minecraft.core.component.PatchedDataComponentMap.get(DataComponentType) line: 61` |
| 34 | 0.56% | `net.minecraft.world.level.chunk.PalettedContainer.readPalette(PalettedContainer$Data, int) line: 96` |
| 35 | 0.52% | `com.google.common.collect.RegularImmutableList.get(int) line: 79` |
| 36 | 0.52% | `java.util.EnumMap.get(Object) line: 247` |
| 37 | 0.51% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 275` |
| 38 | 0.49% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.CRC.updateCRC(int) line: 119` |
| 39 | 0.47% | `ca.spottedleaf.moonrise.common.util.TickThread.isTickThread() line: 122` |
| 40 | 0.46% | `com.google.common.collect.Iterators$5.computeNext() line: 671` |
| 41 | 0.44% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 42 | 0.44% | `it.unimi.dsi.fastutil.objects.ObjectArrayList.grow(int) line: 355` |
| 43 | 0.41% | `ca.spottedleaf.concurrentutil.util.HashUtil.mix(long) line: 92` |
| 44 | 0.39% | `net.minecraft.server.level.ServerChunkCache.getChunk(int, int, ChunkStatus, boolean) line: 320` |
| 45 | 0.36% | `net.minecraft.world.entity.Entity.setDeltaMovement(Vec3) line: 4883` |
| 46 | 0.36% | `net.minecraft.world.entity.Entity.updateFluidHeightAndDoFluidPushing(TagKey, double) line: 4733` |
| 47 | 0.35% | `java.util.ArrayDeque.sub(int, int, int) line: 248` |
| 48 | 0.34% | `net.minecraft.world.level.chunk.ChunkAccess.getSections() line: 237` |
| 49 | 0.34% | `net.minecraft.server.level.ServerLevel.lambda$tick$4(TickRateManager, ProfilerFiller, Entity) line: 802` |
| 50 | 0.32% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.getBlock() line: 641` |
| 51 | 0.31% | `it.unimi.dsi.fastutil.objects.ObjectArrayList.clear() line: 431` |
| 52 | 0.30% | `ca.spottedleaf.moonrise.patches.starlight.light.StarLightEngine.performLightIncrease(LightChunkGetter) line: 1125` |
| 53 | 0.30% | `java.lang.ThreadLocal.get() line: 172` |
| 54 | 0.29% | `java.util.EnumMap.unmaskNull(Object) line: 127` |
| 55 | 0.29% | `java.lang.Enum.ordinal() line: 128` |
| 56 | 0.29% | `net.minecraft.world.level.material.FluidState.getType() line: 58` |
| 57 | 0.27% | `ca.spottedleaf.moonrise.patches.collisions.CollisionUtil.getCollisionsForBlocksOrWorldBorder(Level, Entity, AABB, List, List, int, BiPredicate) line: 1998` |
| 58 | 0.27% | `it.unimi.dsi.fastutil.longs.LongOpenHashSet.clear() line: 493` |
| 59 | 0.27% | `net.minecraft.util.SimpleBitStorage.get(int) line: 333` |
| 60 | 0.26% | `it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap.put(Object, double) line: 486` |

## Top 30 callers of hot leaves

| # | % | method |
|---:|---:|---|
| 1 | 7.89% | `net.minecraft.server.level.ServerLevel.tick(BooleanSupplier) line: 793` |
| 2 | 6.11% | `net.minecraft.world.entity.Entity.setOldPos() line: 2174` |
| 3 | 6.08% | `net.minecraft.server.level.ChunkMap.newTrackerTick() line: 1016` |
| 4 | 4.28% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.applyAndClear(Entity) line: 54` |
| 5 | 3.35% | `net.minecraft.world.entity.Entity.setSwimming(boolean) line: 3528` |
| 6 | 2.87% | `net.minecraft.world.phys.AABB.intersects(AABB) line: 231` |
| 7 | 2.75% | `net.minecraft.network.syncher.SynchedEntityData.get(EntityDataAccessor) line: 53` |
| 8 | 2.41% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.get(long) line: 224` |
| 9 | 2.30% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 10 | 2.19% | `net.minecraft.world.entity.item.ItemEntity.tick() line: 188` |
| 11 | 2.10% | `net.minecraft.world.entity.Entity.getGravity() line: 1842` |
| 12 | 1.79% | `net.minecraft.server.level.ChunkMap.newTrackerTick() line: 1013` |
| 13 | 1.68% | `net.minecraft.world.phys.Vec3.add(double, double, double) line: 119` |
| 14 | 1.58% | `net.minecraft.world.entity.Entity.updateFluidHeightAndDoFluidPushing(TagKey, double) line: 4788` |
| 15 | 1.49% | `net.minecraft.server.level.ChunkMap$TrackedEntity.moonrise$tick(NearbyPlayers$TrackedChunk) line: 1154` |
| 16 | 1.43% | `net.minecraft.world.entity.Entity.updateInWaterStateAndDoWaterCurrentPushing() line: 1970` |
| 17 | 1.43% | `net.minecraft.world.entity.item.ItemEntity.tick() line: 157` |
| 18 | 1.31% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 19 | 1.05% | `net.minecraft.world.level.Level.noCollision(Entity, AABB) line: 1502` |
| 20 | 1.00% | `net.minecraft.server.MinecraftServer.tickChildren(BooleanSupplier) line: 1725` |
| 21 | 0.91% | `net.minecraft.world.entity.Entity.collide(Vec3) line: 1516` |
| 22 | 0.88% | `net.minecraft.server.level.ServerEntity.sendChanges() line: 212` |
| 23 | 0.88% | `net.minecraft.world.level.NaturalSpawner.createState(int, Iterable, NaturalSpawner$ChunkGetter, LocalMobCapCalculator, boolean) line: 80` |
| 24 | 0.85% | `it.unimi.dsi.fastutil.objects.ReferenceCollections$UnmodifiableCollection.contains(Object) line: 344` |
| 25 | 0.85% | `net.minecraft.world.level.chunk.LevelChunk.getBlockStateFinal(int, int, int) line: 279` |
| 26 | 0.75% | `net.minecraft.world.entity.Entity.checkSupportingBlock(boolean, Vec3) line: 1062` |
| 27 | 0.72% | `net.minecraft.world.level.chunk.LevelChunk.getBlockState(BlockPos) line: 285` |
| 28 | 0.68% | `net.minecraft.world.entity.Entity.updateInWaterStateAndDoFluidPushing() line: 1963` |
| 29 | 0.66% | `java.util.ArrayList.toArray() line: 369` |
| 30 | 0.66% | `net.minecraft.world.entity.Entity.isInLava() line: 2081` |

GC pauses: 0, total 0 ms

