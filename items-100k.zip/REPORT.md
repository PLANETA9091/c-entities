# Базовый прогон: `items-100k`

Сервер: `1.21.8-60-29c8822 (MC: 1.21.8)`

## Итог

| метрика | значение |
|---|---|
| энтити заспавнено | 100000 (items 100000 / stands 0 / zombies 0) (merge-усадка: 62930 → 62930) |
| тайл-энтити | 0 (hoppers 0 / furnaces 0) |
| MSPT p50 / p90 / p99 / max, мс | 65.825 / 72.598 / 107.992 / 153.920 |
| MSPT mean, мс | 69.176 |
| TPS-оценка (1000/p50) | 15.2 |
| heap used / max, МБ | 1401.0 / 8192.0 |
| замеров тиков | 600 |

## Что жрёт время (JFR, top-15 self-time)

| # | % | метод |
|---:|---:|---|
| 1 | 7.89% | `net.minecraft.world.level.entity.EntityTickList.forEach(Consumer) line: 39` |
| 2 | 5.84% | `net.minecraft.world.entity.Entity.setOldPos(Vec3) line: 2182` |
| 3 | 5.08% | `net.minecraft.server.level.ServerEntity.sendChanges() line: 151` |
| 4 | 3.36% | `net.minecraft.world.entity.Entity.setSharedFlag(int, boolean) line: 3599` |
| 5 | 3.12% | `net.minecraft.world.entity.InsideBlockEffectApplier$StepBasedCollector.flushStep() line: 70` |
| 6 | 2.87% | `net.minecraft.world.phys.AABB.intersects(double, double, double, double, double, double) line: 235` |
| 7 | 2.15% | `net.minecraft.world.entity.Entity.applyEffectsFromBlocks() line: 1269` |
| 8 | 2.10% | `net.minecraft.world.entity.Entity.isNoGravity() line: 1830` |
| 9 | 1.98% | `net.minecraft.network.syncher.SynchedEntityData.getItem(EntityDataAccessor) line: 49` |
| 10 | 1.78% | `net.minecraft.world.entity.Entity.moonrise$getChunkData() line: 411` |
| 11 | 1.63% | `net.minecraft.world.phys.Vec3.<init>(double, double, double) line: 69` |
| 12 | 1.57% | `net.minecraft.world.level.chunk.PalettedContainer.get(int) line: 256` |
| 13 | 1.48% | `net.minecraft.server.level.ChunkMap$TrackedEntity.moonrise$clearPlayers() line: 1215` |
| 14 | 1.24% | `net.minecraft.world.entity.item.ItemEntity.getItem() line: 518` |
| 15 | 1.23% | `it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap.put(Object, double) line: 485` |

