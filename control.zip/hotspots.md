# JVM hotspots (JFR ExecutionSample)

Samples: 1158

## Top 60 by self-time (leaf frames)

| # | % | method |
|---:|---:|---|
| 1 | 2.94% | `com.google.common.collect.Iterators$5.computeNext() line: 671` |
| 2 | 2.50% | `com.google.common.collect.RegularImmutableList.get(int) line: 79` |
| 3 | 2.42% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.CRC.updateCRC(int) line: 119` |
| 4 | 2.33% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 5 | 2.07% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 742` |
| 6 | 1.99% | `net.minecraft.world.level.levelgen.SurfaceRules$TestRule.tryApply(int, int, int) line: 712` |
| 7 | 1.81% | `ca.spottedleaf.moonrise.patches.starlight.light.StarLightEngine.performLightIncrease(LightChunkGetter) line: 1125` |
| 8 | 1.73% | `ca.spottedleaf.moonrise.patches.chunk_system.scheduling.NewChunkHolder.addGenerationBlockingNeighbour(NewChunkHolder) line: 514` |
| 9 | 1.64% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.setupBlock() line: 824` |
| 10 | 1.47% | `net.minecraft.world.level.chunk.LinearPalette.idFor(Object) line: 52` |
| 11 | 1.38% | `java.lang.String.hashCode() line: 2358` |
| 12 | 1.30% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 714` |
| 13 | 1.30% | `org.objectweb.asm.ClassReader.readCode(MethodVisitor, Context, int) line: 1722` |
| 14 | 1.21% | `java.util.concurrent.ConcurrentHashMap.get(Object) line: 946` |
| 15 | 1.21% | `org.objectweb.asm.ClassReader.readCode(MethodVisitor, Context, int) line: 2425` |
| 16 | 1.21% | `net.minecraft.world.level.block.state.BlockBehaviour$BlockStateBase.blocksMotion() line: 651` |
| 17 | 1.12% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 758` |
| 18 | 1.12% | `net.minecraft.world.level.chunk.ImposterProtoChunk.getNoiseBiome(int, int, int) line: 175` |
| 19 | 0.95% | `net.minecraft.world.level.levelgen.NoiseChunk.updateForZ(int, double) line: 325` |
| 20 | 0.86% | `java.lang.StringLatin1.hashCode(byte[]) line: 194` |
| 21 | 0.86% | `net.minecraft.world.level.levelgen.Heightmap.primeHeightmaps(ChunkAccess, Set) line: 57` |
| 22 | 0.78% | `com.sun.crypto.provider.CounterMode.implCrypt(byte[], int, int, byte[], int) line: 194` |
| 23 | 0.78% | `java.lang.AbstractStringBuilder.ensureCapacityInternal(int) line: 243` |
| 24 | 0.69% | `com.sun.crypto.provider.GHASH.processBlocks(byte[], int, int, long[], long[]) line: 282` |
| 25 | 0.69% | `java.util.Arrays.copyOf(byte[], int) line: 3541` |
| 26 | 0.69% | `net.minecraft.world.level.levelgen.carver.WorldCarver.carveEllipsoid(CarvingContext, CarverConfiguration, ChunkAccess, Function, Aquifer, double, double, double, double, double, CarvingMask, WorldCarver$CarveSkipChecker) line: 105` |
| 27 | 0.69% | `net.minecraft.world.level.levelgen.synth.ImprovedNoise.gradDot(int, double, double, double) line: 78` |
| 28 | 0.60% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 764` |
| 29 | 0.60% | `java.util.regex.Pattern$CharPropertyGreedy.match(Matcher, int, CharSequence) line: 4452` |
| 30 | 0.60% | `net.minecraft.world.level.chunk.ProtoChunk.getBlockState(int, int, int) line: 117` |
| 31 | 0.60% | `net.minecraft.util.Mth.lerp3(double, double, double, double, double, double, double, double, double, double, double) line: 561` |
| 32 | 0.60% | `net.minecraft.world.level.chunk.LevelChunkSection.updateBlockCallback(int, int, int, BlockState, BlockState) line: 129` |
| 33 | 0.60% | `net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator.doFill(Blender, StructureManager, RandomState, ChunkAccess, int, int) line: 378` |
| 34 | 0.60% | `it.unimi.dsi.fastutil.ints.IntArraySet.findKey(int) line: 205` |
| 35 | 0.60% | `net.minecraft.world.level.chunk.PalettedContainer.pack(IdMap, PalettedContainer$Strategy) line: 350` |
| 36 | 0.52% | `java.util.zip.ZipFile$Source.getEntryPos(String, boolean) line: 1823` |
| 37 | 0.52% | `net.minecraft.world.level.levelgen.synth.SimplexNoise.dot(int[], double, double, double) line: 56` |
| 38 | 0.52% | `it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap$MapIterator.nextEntry() line: 643` |
| 39 | 0.43% | `java.lang.invoke.VarHandleByteArrayAsLongs$ArrayHandle.index(byte[], int) line: 101` |
| 40 | 0.43% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 767` |
| 41 | 0.43% | `java.util.HashMap$ValueSpliterator.forEachRemaining(Consumer) line: 1787` |
| 42 | 0.43% | `org.objectweb.asm.ClassReader.readUtf(int, int, char[]) line: 3733` |
| 43 | 0.43% | `net.minecraft.world.level.biome.Climate$RTree.lambda$comparator$3(int, boolean, Climate$RTree$Node) line: 329` |
| 44 | 0.43% | `net.minecraft.world.level.levelgen.synth.PerlinNoise.wrap(double) line: 190` |
| 45 | 0.43% | `net.minecraft.core.HolderSet$Named.contains(Holder) line: 209` |
| 46 | 0.43% | `net.minecraft.world.level.levelgen.DensityFunctions$EndIslandDensityFunction.getHeightValue(SimplexNoise, int, int) line: 554` |
| 47 | 0.43% | `net.minecraft.util.ZeroBitStorage.getAll(IntConsumer) line: 52` |
| 48 | 0.35% | `java.math.BigInteger.implMultiplyToLen(int[], int, int[], int, int[]) line: 1819` |
| 49 | 0.35% | `com.sun.crypto.provider.CounterMode.increment(byte[]) line: 164` |
| 50 | 0.35% | `java.util.regex.Matcher.appendExpandedReplacement(Appendable, String) line: 1142` |
| 51 | 0.35% | `java.util.HashMap.resize() line: 741` |
| 52 | 0.35% | `org.objectweb.asm.SymbolTable.put(SymbolTable$Entry) line: 445` |
| 53 | 0.35% | `ca.spottedleaf.moonrise.patches.collisions.CollisionUtil$MergedVoxelCoordinateList.merge(double[], double, double[], double, boolean, boolean) line: 1496` |
| 54 | 0.35% | `net.minecraft.resources.ResourceLocation.toString() line: 139` |
| 55 | 0.35% | `net.minecraft.world.level.biome.Climate$RTree.buildParameterSpace(List) line: 380` |
| 56 | 0.35% | `net.minecraft.world.level.chunk.PalettedContainer.readPalette(PalettedContainer$Data, int) line: 96` |
| 57 | 0.35% | `net.minecraft.world.level.levelgen.Heightmap.update(int, int, int, BlockState) line: 86` |
| 58 | 0.35% | `net.minecraft.server.level.ServerLevel.tickChunk(LevelChunk, int) line: 916` |
| 59 | 0.35% | `net.minecraft.nbt.CompoundTag.write(DataOutput) line: 180` |
| 60 | 0.26% | `com.sun.crypto.provider.GHASH.blockMult(long[], long[]) line: 93` |

## Top 30 callers of hot leaves

| # | % | method |
|---:|---:|---|
| 1 | 5.96% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.initBlock() line: 326` |
| 2 | 3.71% | `org.objectweb.asm.ClassReader.readMethod(ClassVisitor, Context, int) line: 1512` |
| 3 | 2.94% | `com.google.common.collect.AbstractIterator.tryToComputeNext() line: 145` |
| 4 | 2.50% | `net.minecraft.world.level.chunk.status.ChunkDependencies.get(int) line: 51` |
| 5 | 2.42% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.setupNoRandPartC() line: 948` |
| 6 | 2.33% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.get(long) line: 224` |
| 7 | 1.99% | `net.minecraft.world.level.levelgen.SurfaceRules$SequenceRule.tryApply(int, int, int) line: 586` |
| 8 | 1.73% | `ca.spottedleaf.moonrise.patches.starlight.light.SkyStarLightEngine.lightChunk(LightChunkGetter, ChunkAccess, boolean) line: 543` |
| 9 | 1.73% | `ca.spottedleaf.moonrise.patches.chunk_system.scheduling.ChunkTaskScheduler.checkNeighbour(int, int, ChunkStatus, NewChunkHolder, List, Priority) line: 805` |
| 10 | 1.55% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.setupNoRandPartA() line: 885` |
| 11 | 1.38% | `net.minecraft.world.level.chunk.PalettedContainer.getAndSet(int, Object) line: 226` |
| 12 | 1.30% | `net.minecraft.world.level.chunk.status.ChunkStatusTasks.generateFeatures(WorldGenContext, ChunkStep, StaticCache2D, ChunkAccess) line: 145` |
| 13 | 1.21% | `net.minecraft.world.level.LevelReader.getNoiseBiome(int, int, int) line: 78` |
| 14 | 1.21% | `net.minecraft.world.level.levelgen.Heightmap.update(int, int, int, BlockState) line: 86` |
| 15 | 0.95% | `com.sun.crypto.provider.CounterMode.crypt(byte[], int, int, byte[], int) line: 181` |
| 16 | 0.95% | `com.sun.crypto.provider.GHASH.update(byte[], int, int) line: 180` |
| 17 | 0.95% | `net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator.doFill(Blender, StructureManager, RandomState, ChunkAccess, int, int) line: 370` |
| 18 | 0.86% | `java.lang.String.hashCode() line: 2358` |
| 19 | 0.86% | `net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator.lambda$fillFromNoise$11(ChunkAccess, int, NoiseSettings, int, Blender, StructureManager, RandomState, int) line: 312` |
| 20 | 0.86% | `net.minecraft.world.level.levelgen.DensityFunctions$EndIslandDensityFunction.compute(DensityFunction$FunctionContext) line: 570` |
| 21 | 0.69% | `org.objectweb.asm.SymbolTable.hash(int, String) line: 1378` |
| 22 | 0.69% | `net.minecraft.world.level.levelgen.NoiseBasedChunkGenerator.buildSurface(ChunkAccess, WorldGenerationContext, RandomState, StructureManager, BiomeManager, Registry, Blender) line: 247` |
| 23 | 0.69% | `net.minecraft.world.level.levelgen.carver.CaveWorldCarver.createTunnel(CarvingContext, CaveCarverConfiguration, ChunkAccess, Function, long, Aquifer, double, double, double, double, double, float, float, float, int, int, double, CarvingMask, WorldCarver$CarveSkipChecker) line: 217` |
| 24 | 0.69% | `net.minecraft.world.level.chunk.LevelChunkSection.setBlockState(int, int, int, BlockState, boolean) line: 167` |
| 25 | 0.60% | `java.lang.AbstractStringBuilder.append(char) line: 811` |
| 26 | 0.60% | `java.util.regex.Pattern$GroupHead.match(Matcher, int, CharSequence) line: 4969` |
| 27 | 0.60% | `net.neoforged.srgutils.MappingFile.remapClass(String) line: 85` |
| 28 | 0.60% | `net.minecraft.world.level.biome.Climate$RTree$SubTree.<init>(List) line: 436` |
| 29 | 0.60% | `net.minecraft.world.level.chunk.ProtoChunk.getBlockState(BlockPos) line: 108` |
| 30 | 0.60% | `net.minecraft.world.level.levelgen.NoiseChunk$NoiseInterpolator.compute(DensityFunction$FunctionContext) line: 748` |

GC pauses: 0, total 0 ms

