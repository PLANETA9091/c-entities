# Базовый прогон: `control`

Сервер: `1.21.8-60-29c8822 (MC: 1.21.8)`

## Итог

| метрика | значение |
|---|---|
| энтити заспавнено | 0 (items 0 / stands 0 / zombies 0) |
| тайл-энтити | 0 (hoppers 0 / furnaces 0) |
| MSPT p50 / p90 / p99 / max, мс | 0.158 / 0.267 / 0.369 / 4.868 |
| MSPT mean, мс | 0.186 |
| TPS-оценка (1000/p50) | 20.0 |
| heap used / max, МБ | 574.6 / 8192.0 |
| замеров тиков | 600 |

## Что жрёт время (JFR, top-15 self-time)

| # | % | метод |
|---:|---:|---|
| 1 | 2.94% | `com.google.common.collect.Iterators$5.computeNext() line: 671` |
| 2 | 2.50% | `com.google.common.collect.RegularImmutableList.get(int) line: 79` |
| 3 | 2.42% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.CRC.updateCRC(int) line: 119` |
| 4 | 2.33% | `ca.spottedleaf.concurrentutil.map.ConcurrentLong2ReferenceChainedHashTable.getNode(long) line: 207` |
| 5 | 2.07% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 742` |
| 6 | 1.99% | `net.minecraft.world.level.levelgen.SurfaceRules$TestRule.tryApply(int, int, int) line: 712` |
| 7 | 1.81% | `ca.spottedleaf.moonrise.patches.starlight.light.StarLightEngine.performLightIncrease(LightChunkGetter) line: 1125` |
| 8 | 1.73% | `ca.spottedleaf.moonrise.patches.chunk_system.scheduling.NewChunkHolder.addGenerationBlockingNeighbour(NewChunkHolder) line: 514` |
| 9 | 1.64% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.setupBlock() line: 824` |
| 10 | 1.47% | `net.minecraft.world.level.chunk.LinearPalette.idFor(Object) line: 52` |
| 11 | 1.38% | `java.lang.String.hashCode() line: 2358` |
| 12 | 1.30% | `paperclip.libs.org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream.getAndMoveToFrontDecode() line: 714` |
| 13 | 1.30% | `org.objectweb.asm.ClassReader.readCode(MethodVisitor, Context, int) line: 1722` |
| 14 | 1.21% | `java.util.concurrent.ConcurrentHashMap.get(Object) line: 946` |
| 15 | 1.21% | `org.objectweb.asm.ClassReader.readCode(MethodVisitor, Context, int) line: 2425` |

